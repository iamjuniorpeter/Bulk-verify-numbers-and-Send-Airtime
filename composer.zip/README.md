# bulk_airtime
Bulk verify numbers (numverify.com), send airtime (africastalking.com)
